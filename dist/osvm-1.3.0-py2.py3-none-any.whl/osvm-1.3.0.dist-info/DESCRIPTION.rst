Detection of Online Impersonation based on User Profiling in Social Networks through Optimized SVM


